<p>Соединение с базой данных успешно протестировано / Connection to database tested</p>
<form action="?r=<?=time()?>" method="post">
<input type="hidden" name="step" value="3">
<table>
<tr><th><input type="submit" value="далее / next"></th></tr>
</table>
</form>
