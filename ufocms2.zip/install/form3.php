<p>Структура базы данных успешно создана / Database structure created</p>
<form action="?r=<?=time()?>" method="post">
<input type="hidden" name="step" value="4">
<table>
<tr><th><input type="submit" value="далее / next"></th></tr>
</table>
</form>
