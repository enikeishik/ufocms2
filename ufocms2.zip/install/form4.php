<p>Все готово к работе / All done</p>
<p>Перейти к системе управления / Goto content management system <a href="/admin">ufocms</a></p>
