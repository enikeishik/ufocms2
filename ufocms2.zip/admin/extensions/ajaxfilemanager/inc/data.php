<pre>Array
(
    [currentFolderPath] => ../../../files/
    [new_folder] => images
)
</pre>

14/Nov/2016 16:15:15