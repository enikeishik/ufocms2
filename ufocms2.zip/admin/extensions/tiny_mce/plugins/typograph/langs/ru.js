tinyMCE.addI18n('ru.typograph',{
	desc : 'Типограф - делает текст красивым'
});
