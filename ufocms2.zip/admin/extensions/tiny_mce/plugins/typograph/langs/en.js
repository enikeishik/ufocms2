tinyMCE.addI18n('en.typograph',{
	desc : 'Typograph - makes text nicely'
});
