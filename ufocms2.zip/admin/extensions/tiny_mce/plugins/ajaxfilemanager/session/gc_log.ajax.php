<?php die(); ?>
gc start at 23/May/2017 08:30:22
