tinyMCE.addI18n('ru.word2text',{
	desc : 'Word2text - загружает документы Word/OpenOffice и извлекает текст'
});
