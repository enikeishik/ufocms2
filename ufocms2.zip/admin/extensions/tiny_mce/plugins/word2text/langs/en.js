tinyMCE.addI18n('en.word2text',{
	desc : 'Word2text - upload Word/Open Office document and extract plain text'
});
