<?php require_once 'layout-begin.php'; ?>

<?php echo $this->ui->treeItems(); ?>

<?php require_once 'layout-end.php'; ?>