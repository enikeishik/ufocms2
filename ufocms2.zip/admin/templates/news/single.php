<?php require_once 'templates/layout-begin.php'; ?>

<?php echo $this->ui->singleItems(); ?>

<?php require_once 'templates/layout-end.php'; ?>