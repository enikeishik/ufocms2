<?php require_once 'layout-begin.php'; ?>

<div>Complete</div>

<?php require_once 'layout-end.php'; ?>