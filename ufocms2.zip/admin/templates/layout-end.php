
<?php
if (!is_null($this->debug)) {
    include_once 'block-debug.php';
} else {
    //echo '<div class="debug"><div>mem: ' . memory_get_peak_usage() . '</div></div>';
}
?>

</div></div>

</body>
<html>