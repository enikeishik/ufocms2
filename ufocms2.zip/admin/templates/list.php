<?php require_once 'layout-begin.php'; ?>

<?php echo $this->ui->filters(); ?>

<?php echo $this->ui->pagination(); ?>

<?php echo $this->ui->listItems(); ?>

<?php echo $this->ui->pagination(); ?>

<?php require_once 'layout-end.php'; ?>