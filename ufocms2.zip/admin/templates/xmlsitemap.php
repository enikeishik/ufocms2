<?php require_once 'layout-begin.php'; ?>

<iframe src="/xsm.php?build=<?=time()?>" width="100%" height="600" frameborder="0" style="border: 1px solid #999;"></iframe>

<?php require_once 'layout-end.php'; ?>