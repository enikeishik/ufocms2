<?php require_once 'layout-begin.php'; ?>

<?php echo $this->ui->form(); ?>

<?php require_once 'layout-end.php'; ?>