<div class="debug">
<div>
    <?php echo 'time: ' . $this->debug->getExecutionTime() . '; mem: ' . memory_get_peak_usage(); ?>
    <span onclick="showHide('debug-this')">this</span>
    <span onclick="showHide('debug-trace')">trace</span>
</div>
<pre id="debug-this"><?php echo htmlspecialchars(var_dump($this)); //htmlspecialchars(print_r($this, true)); ?></pre>
<pre id="debug-trace">
<?php
echo 'Total ' . $this->debug->getTraceCounter() . " operations traced:\r\n";
$trace = $this->debug->getTrace();
foreach ($trace as $traceItem) {
    echo    $traceItem['time'] . "\t" . 
            htmlspecialchars($traceItem['operation']) . 
            (null !== $traceItem['stack'] ? "\t" . implode('\\', (function ($stack) { $arr = []; foreach ($stack as $s) { $arr[] = array_pop(explode('\\', $s['class'])) . '::' . $s['function']; } array_shift($arr); array_shift($arr); array_shift($arr); return array_reverse($arr); })($sql['stack'])) : '') . 
            "\r\n";
}
?>
</pre>
<script stype="text/javascript">showHide('debug-this');showHide('debug-trace');</script>
<?php
$errors = $this->debug->getErrors();
if (0 < $errcnt = count($errors)) {
    echo "<pre style='background-color: #fcc;'>\r\n";
    echo 'Total ' . $errcnt . " errors:\r\n";
    foreach ($errors as $err) {
        echo htmlspecialchars($err) . "\r\n";
    }
    echo "</pre>\r\n";
}
?>
</div>
